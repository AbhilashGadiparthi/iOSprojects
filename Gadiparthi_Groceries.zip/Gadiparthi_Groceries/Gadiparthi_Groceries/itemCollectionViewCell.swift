//
//  itemCollectionViewCell.swift
//  Gadiparthi_Groceries
//
//  Created by Abhilash Gadiparthi on 4/17/24.
//

import UIKit

class itemCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageOL: UIImageView!
    func assignItem(with image:UIImage){
        imageOL.image = image
    }
}
