//
//  groceries.swift
//  Gadiparthi_Groceries
//
//  Created by Abhilash Gadiparthi on 4/17/24.
//

import UIKit

// Define the struct
struct Item {
    var itemName: String
    var image: UIImage
    var itemPrice: Double
    var itemExpiry: String
    var itemQuantity: Int
    var itemOrigin: String
    var itemDescription: String
}

// Generate Data for Fruits
let Fruits: [Item] = [
    Item(itemName: "Apple", image: UIImage(named: "Apple")!, itemPrice: 1.99, itemExpiry: "2024-04-22", itemQuantity: 15, itemOrigin: "Canada", itemDescription: "Crisp, tart green apples"),
    Item(itemName: "Banana", image: UIImage(named: "Banana")!, itemPrice: 0.59, itemExpiry: "2024-04-17", itemQuantity: 20, itemOrigin: "Colombia", itemDescription: "Versatile cooking bananas"),
    Item(itemName: "Orange", image: UIImage(named: "Orange")!, itemPrice: 0.89, itemExpiry: "2024-04-18", itemQuantity: 12, itemOrigin: "Spain", itemDescription: "Easy-to-peel, sweet clementines"),
    Item(itemName: "Mango", image: UIImage(named: "Mango")!, itemPrice: 4.49, itemExpiry: "2024-04-24", itemQuantity: 8, itemOrigin: "Chile", itemDescription: "Plump, antioxidant-rich blueberries"),
    Item(itemName: "Strawberry", image: UIImage(named: "Strawberry")!, itemPrice: 3.99, itemExpiry: "2024-04-23", itemQuantity: 15, itemOrigin: "Canada", itemDescription: "Sweet, tangy raspberries"),
    Item(itemName: "Pineapple", image: UIImage(named: "Pineapple")!, itemPrice: 2.79, itemExpiry: "2024-04-25", itemQuantity: 10, itemOrigin: "Thailand", itemDescription: "Creamy, tropical coconut"),
    Item(itemName: "Grape", image: UIImage(named: "Grape")!, itemPrice: 2.19, itemExpiry: "2024-04-24", itemQuantity: 18, itemOrigin: "Brazil", itemDescription: "Juicy, orange-fleshed papaya"),
    Item(itemName: "Watermelon", image: UIImage(named: "Watermelon")!, itemPrice: 4.49, itemExpiry: "2024-04-26", itemQuantity: 10, itemOrigin: "Mexico", itemDescription: "Sweet, succulent honeydew melon"),
    Item(itemName: "Kiwi", image: UIImage(named: "Kiwi")!, itemPrice: 1.49, itemExpiry: "2024-04-23", itemQuantity: 14, itemOrigin: "Italy", itemDescription: "Golden-fleshed, sweet kiwi fruit"),
    Item(itemName: "Peach", image: UIImage(named: "Peach")!, itemPrice: 1.79, itemExpiry: "2024-04-24", itemQuantity: 11, itemOrigin: "Spain", itemDescription: "Smooth-skinned, juicy nectarines")
]

// Generate Data for Vegetables
let vegetables: [Item] = [
    Item(itemName: "Carrot", image: UIImage(named: "Carrot")!, itemPrice: 1.19, itemExpiry: "2024-04-19", itemQuantity: 10, itemOrigin: "North Carolina", itemDescription: "Nutritious sweet potatoes"),
    Item(itemName: "Broccoli", image: UIImage(named: "Broccoli")!, itemPrice: 1.99, itemExpiry: "2024-04-20", itemQuantity: 8, itemOrigin: "Canada", itemDescription: "Versatile cauliflower heads"),
    Item(itemName: "Tomato", image: UIImage(named: "Tomato")!, itemPrice: 1.69, itemExpiry: "2024-04-18", itemQuantity: 7, itemOrigin: "USA", itemDescription: "Nutrient-rich kale leaves"),
    Item(itemName: "Bell Pepper", image: UIImage(named: "BellPepper")!, itemPrice: 1.29, itemExpiry: "2024-04-21", itemQuantity: 10, itemOrigin: "Italy", itemDescription: "Sweet, bite-sized cherry tomatoes"),
    Item(itemName: "Cucumber", image: UIImage(named: "Cucumber")!, itemPrice: 0.99, itemExpiry: "2024-04-19", itemQuantity: 12, itemOrigin: "Mexico", itemDescription: "Fresh, tender zucchinis"),
    Item(itemName: "Onion", image: UIImage(named: "Onion")!, itemPrice: 2.49, itemExpiry: "2024-04-20", itemQuantity: 9, itemOrigin: "Peru", itemDescription: "Crunchy, green asparagus spears"),
    Item(itemName: "Potato", image: UIImage(named: "Potato")!, itemPrice: 1.79, itemExpiry: "2024-04-22", itemQuantity: 8, itemOrigin: "USA", itemDescription: "Nutty, flavorful Brussels sprouts"),
    Item(itemName: "Lettuce", image: UIImage(named: "Lettuce")!, itemPrice: 1.69, itemExpiry: "2024-04-21", itemQuantity: 10, itemOrigin: "USA", itemDescription: "Nutrient-rich broccoli florets"),
    Item(itemName: "Zucchini", image: UIImage(named: "Zucchini")!, itemPrice: 0.99, itemExpiry: "2024-04-20", itemQuantity: 15, itemOrigin: "USA", itemDescription: "Sweet, crunchy baby carrots"),
    Item(itemName: "Spinach", image: UIImage(named: "Spinach")!, itemPrice: 1.49, itemExpiry: "2024-04-23", itemQuantity: 10, itemOrigin: "Mexico", itemDescription: "Sweet, vibrant red bell peppers")
]

// Generate Data for Dairy Products
let DairyProducts: [Item] = [
    Item(itemName: "Milk", image: UIImage(named: "Milk")!, itemPrice: 2.99, itemExpiry: "2024-04-25", itemQuantity: 20, itemOrigin: "USA", itemDescription: "Farm-fresh eggs"),
    Item(itemName: "Cheese", image: UIImage(named: "Cheese")!, itemPrice: 3.49, itemExpiry: "2024-04-27", itemQuantity: 5, itemOrigin: "USA", itemDescription: "Creamy whole milk"),
    Item(itemName: "Yogurt", image: UIImage(named: "Yogurt")!, itemPrice: 4.99, itemExpiry: "2024-04-26", itemQuantity: 8, itemOrigin: "Greece", itemDescription: "Thick, creamy Greek yogurt"),
    Item(itemName: "Butter", image: UIImage(named: "Butter")!, itemPrice: 2.79, itemExpiry: "2024-04-29", itemQuantity: 10, itemOrigin: "USA", itemDescription: "Sharp cheddar cheese"),
    Item(itemName: "Cream", image: UIImage(named: "Cream")!, itemPrice: 3.99, itemExpiry: "2024-04-28", itemQuantity: 7, itemOrigin: "USA", itemDescription: "Rich, creamy unsalted butter"),
    Item(itemName: "SourCream", image: UIImage(named: "SourCream")!, itemPrice: 1.79, itemExpiry: "2024-04-30", itemQuantity: 8, itemOrigin: "USA", itemDescription: "Smooth, tangy sour cream"),
    Item(itemName: "CottageCheese", image: UIImage(named: "CottageCheese")!, itemPrice: 2.49, itemExpiry: "2024-05-01", itemQuantity: 6, itemOrigin: "USA", itemDescription: "Rich, indulgent heavy cream"),
    Item(itemName: "Mozzarella", image: UIImage(named: "Mozzarella")!, itemPrice: 2.69, itemExpiry: "2024-04-28", itemQuantity: 10, itemOrigin: "USA", itemDescription: "Melty, stretchy mozzarella cheese"),
    Item(itemName: "Ricotta", image: UIImage(named: "Ricotta")!, itemPrice: 2.99, itemExpiry: "2024-04-27", itemQuantity: 8, itemOrigin: "USA", itemDescription: "Creamy almond milk"),
    Item(itemName: "CondensedMilk", image: UIImage(named: "CondensedMilk")!, itemPrice: 1.99, itemExpiry: "2024-04-30", itemQuantity: 7, itemOrigin: "USA", itemDescription: "Smooth, creamy cottage cheese")
]

// Generate Data for Bakery Items
let Grains: [Item] = [
    Item(itemName: "Rice", image: UIImage(named: "Rice")!, itemPrice: 2.49, itemExpiry: "2024-04-22", itemQuantity: 12, itemOrigin: "France", itemDescription: "Crusty French baguette"),
    Item(itemName: "Wheat", image: UIImage(named: "Wheat")!, itemPrice: 1.99, itemExpiry: "2024-04-21", itemQuantity: 15, itemOrigin: "France", itemDescription: "Buttery, flaky croissants"),
    Item(itemName: "Barley", image: UIImage(named: "Barley")!, itemPrice: 1.49, itemExpiry: "2024-04-23", itemQuantity: 10, itemOrigin: "USA", itemDescription: "Moist, blueberry-studded muffins"),
    Item(itemName: "Quinoa", image: UIImage(named: "Quinoa")!, itemPrice: 0.99, itemExpiry: "2024-04-25", itemQuantity: 20, itemOrigin: "USA", itemDescription: "Classic chocolate chip cookies"),
    Item(itemName: "Oats", image: UIImage(named: "Oats")!, itemPrice: 2.29, itemExpiry: "2024-04-24", itemQuantity: 8, itemOrigin: "USA", itemDescription: "Warm, gooey cinnamon rolls"),
    Item(itemName: "Corn", image: UIImage(named: "Corn")!, itemPrice: 3.49, itemExpiry: "2024-04-26", itemQuantity: 10, itemOrigin: "USA", itemDescription: "Artisanal sourdough bread"),
    Item(itemName: "Rye", image: UIImage(named: "Rye")!, itemPrice: 9.99, itemExpiry: "2024-04-30", itemQuantity: 5, itemOrigin: "USA", itemDescription: "Decadent chocolate cake"),
    Item(itemName: "Millet", image: UIImage(named: "Millet")!, itemPrice: 6.99, itemExpiry: "2024-05-01", itemQuantity: 6, itemOrigin: "USA", itemDescription: "Homemade apple pie"),
    Item(itemName: "Buckwheat", image: UIImage(named: "Buckwheat")!, itemPrice: 3.99, itemExpiry: "2024-04-28", itemQuantity: 7, itemOrigin: "USA", itemDescription: "Healthy multigrain bread"),
    Item(itemName: "Sorghum", image: UIImage(named: "Sorghum")!, itemPrice: 0.99, itemExpiry: "2024-04-30", itemQuantity: 9, itemOrigin: "USA", itemDescription: "Soft, chewy plain bagels")
]

// Generate Data for Household Items
let Meats: [Item] = [
    Item(itemName: "Chicken", image: UIImage(named: "Chicken")!, itemPrice: 8.99, itemExpiry: "", itemQuantity: 25, itemOrigin: "USA", itemDescription: "Chicken is one of the most popular meats worldwide. It is versatile and can be prepared in various ways, such as grilled, roasted, fried, or stewed. It has a mild flavor and a tender texture."),
    Item(itemName: "Beef", image: UIImage(named: "Beef")!, itemPrice: 12.49, itemExpiry: "", itemQuantity: 10, itemOrigin: "USA", itemDescription: "Beef is the meat from cattle and is consumed in many cultures. It comes in various cuts, including steaks, roasts, and ground beef. It has a rich flavor and can be cooked in different methods like grilling, braising, or stir-frying"),
    Item(itemName: "Pork", image: UIImage(named: "Pork")!, itemPrice: 10.99, itemExpiry: "", itemQuantity: 20, itemOrigin: "USA", itemDescription: "Pork is the meat from pigs and is widely consumed across the globe. It includes cuts such as pork chops, bacon, ham, and pork loin. Pork has a slightly sweet flavor and can be cooked in various ways, including roasting, grilling, or slow cooking."),
    Item(itemName: "Lamb", image: UIImage(named: "Lamb")!, itemPrice: 4.99, itemExpiry: "", itemQuantity: 15, itemOrigin: "USA", itemDescription: "Lamb meat comes from young sheep and is known for its tender texture and distinct flavor. It can be prepared in many ways, such as grilling, roasting, or stewing. Lamb chops and rack of lamb are popular cuts."),
    Item(itemName: "Duck", image: UIImage(named: "Duck")!, itemPrice: 9.99, itemExpiry: "", itemQuantity: 12, itemOrigin: "USA", itemDescription: "Duck meat is rich and flavorful, with a darker color and a slightly gamey taste compared to chicken. It is often roasted to render the fat and achieve crispy skin. Duck breast and confit duck legs are common preparations."),
    Item(itemName: "Turkey", image: UIImage(named: "Turkey")!, itemPrice: 6.99, itemExpiry: "", itemQuantity: 8, itemOrigin: "USA", itemDescription: "Turkey meat is lean and has a mild flavor. It is commonly associated with holiday feasts, but it is also enjoyed year-round in various dishes such as roasted turkey, turkey sandwiches, and turkey chili."),
    Item(itemName: "Venison", image: UIImage(named: "Venison")!, itemPrice: 3.99, itemExpiry: "", itemQuantity: 10, itemOrigin: "USA", itemDescription: "Venison is the meat of deer and other similar animals. It has a rich, gamey flavor and a lean texture. It is often prepared by roasting, grilling, or braising. Venison steaks and venison stew are popular dishes."),
    Item(itemName: "Rabbit", image: UIImage(named: "Rabbit")!, itemPrice: 5.49, itemExpiry: "", itemQuantity: 15, itemOrigin: "USA", itemDescription: "Rabbit meat is lean and tender, with a mild, slightly sweet flavor. It is commonly used in stews, braises, or roasted dishes. Rabbit meat is considered a delicacy in some cultures and is praised for its delicate taste."),
    Item(itemName: "Quail", image: UIImage(named: "Quail")!, itemPrice: 14.99, itemExpiry: "", itemQuantity: 5, itemOrigin: "USA", itemDescription: "Quail meat is small and delicate, with a rich, slightly gamey flavor. It is often served as whole roasted birds or pan-seared quail breasts. Quail eggs are also prized for their delicate flavor and are used in various dishes."),
    Item(itemName: "Goat", image: UIImage(named: "Goat")!, itemPrice: 2.99, itemExpiry: "", itemQuantity: 12, itemOrigin: "USA", itemDescription: "Goat meat, also known as mutton, is popular in many cuisines around the world. It has a distinctive flavor that can range from mild to strong, depending on the age of the animal. It is commonly used in stews, curries, and grilled dishes.")
]

// Array to store categories along with their respective item lists to retrieve data in collection view.
let allCategories: [[Item]] = [Fruits, vegetables, DairyProducts, Grains, Meats]

// Array to store all category names to display in the table view and as title in the second view.
let categoryNames: [String] = ["Fruits", "vegetables", "DairyProducts", "Grains", "Meats"]
