//
//  GroceriesViewController.swift
//  Gadiparthi_Groceries
//
//  Created by Abhilash Gadiparthi on 4/17/24.
//

import UIKit

class GroceriesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

   
    @IBOutlet weak var itemNameLabel: UILabel!
    
    @IBOutlet weak var itemPriceLabel: UILabel!
    
    @IBOutlet var itemExpireLabel: UILabel!
    
    @IBOutlet weak var itemDescriptionLabel: UILabel!
    
    @IBOutlet weak var itemQuantityLabel: UILabel!
    
    @IBOutlet weak var itemOriginLabel: UILabel!
    
    
    @IBOutlet weak var itemCollectionView: UICollectionView!
    
    
    var item : [Item] = []
    
    var titleName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        itemNameLabel.text = "Product Name:\(item[(0)].itemName)"
        itemPriceLabel.text = "Price $:\(String(item[(0)].itemPrice))"
        itemExpireLabel.text = "Expires On:\(item[0].itemExpiry)"
        itemDescriptionLabel.text = "Description:\(item[0].itemDescription)"
        itemQuantityLabel.text = "Qunatity:\(String(item[0].itemQuantity))"
        itemOriginLabel.text = "Origin:\(item[0].itemOrigin)"
        
        // Do any additional setup after loading the view.

        self.title = titleName
        
        itemCollectionView.dataSource = self
        itemCollectionView.delegate = self
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return item.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = itemCollectionView.dequeueReusableCell(withReuseIdentifier: "itemCell", for: indexPath) as! itemCollectionViewCell

        cell.assignItem(with: item[indexPath.row].image )
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignItemDetails(index: indexPath)
    }
    
    func  assignItemDetails(index:IndexPath){
        itemNameLabel.text = "Product Name:\(item[(index.row)].itemName)"
        itemPriceLabel.text = "Price $:\(String(item[(index.row)].itemPrice))"
        itemExpireLabel.text = "Expires On:\(item[(index.row)].itemExpiry)"
        itemDescriptionLabel.text = "Description:\(item[(index.row)].itemDescription)"
        itemQuantityLabel.text = "Qunatity:\(String(item[(index.row)].itemQuantity))"
        itemOriginLabel.text = "Origin:\(item[(index.row)].itemOrigin)"    }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */



