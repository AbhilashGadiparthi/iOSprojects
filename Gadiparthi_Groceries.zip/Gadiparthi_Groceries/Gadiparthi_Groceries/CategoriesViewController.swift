//
//  ViewController.swift
//  Gadiparthi_Groceries
//
//  Created by Abhilash Gadiparthi on 4/17/24.
//

import UIKit

    class CategoriesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return categoryNames.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = categoryTableViewOL.dequeueReusableCell(withIdentifier: "categoryCell", for: indexPath)
            cell.textLabel?.text = categoryNames[indexPath.row]
            return cell
        }
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            performSegue(withIdentifier: "groceriesSegue", sender: indexPath.row)
        }
    
    @IBOutlet weak var categoryTableViewOL: UITableView!
    
    

        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
//            categoryTableViewOL.register(UINib(nibName: "YourCustomCellNibName", bundle: nil), forCellReuseIdentifier: "viewCell")
            categoryTableViewOL.delegate = self
            categoryTableViewOL.dataSource = self
            
            self.title = "Categories"
        }
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            if transition == "groceriesSegue",let selectedIndex = sender as? Int{
                let destination = segue.destination as! GroceriesViewController
                destination.item = allCategories[selectedIndex]
                print(allCategories[selectedIndex].count
    )
                destination.titleName = categoryNames[selectedIndex]
            }
        }


    }




