import Foundation

var capitals = ["Arkansas":"LittleRock", "Georgia":"Atlanta"]
print(capitals)
print(capitals.count)

var numbers = [1:"One",2:"Two",3:"Three"]
print(numbers)

numbers[4] = "Four"
print(numbers)

var cources = [44542:"java", 44560:"Database", 44613:"Data Visualization"]
print("Before changing the course \(cources)")

cources[44542] = "Java Script"
print("After changing the course \(cources)")

print(cources[44542])

cources.removeValue(forKey: 44613)
print(cources)

for (key,values) in cources{
    print(key)
}

for (key,values) in cources{
    print(values)
}

for(key,values) in cources{
    print("\(key) : \(values)")
}

//Sets

var players : Set<String> = ["David Warner", "Virat Kohli", "Kane Mowa","Steve Smith"]
print(players.count)

print(players)

print(players.contains("Steve Smith"))

players.insert("Maxwell")
print(players)

players.remove("David Warner")
print(players)

var primeNumbers : Set<Int> = [2,3,5,7,11]
var numberList : Set<Int> = [1,2,5,9]
var unionSet : Set<Int> = primeNumbers.union(numberList)
print(unionSet)

var intersectionSet : Set<Int> = primeNumbers.intersection(numberList)
print(intersectionSet)

var subtractionSet : Set<Int> = primeNumbers.subtracting(numberList)
print(subtractionSet)

var symmDiffSet :Set<Int> = primeNumbers.symmetricDifference(numberList)
print(symmDiffSet)

print(primeNumbers.isSubset(of: numberList))

//Arrays

var number:[Int] = [2,3,4]
print(number)

var emptyArray = [Int]()
print(emptyArray)

var programmingLanguages = ["Swift","Java","Python"]
programmingLanguages[0] = "Java Script"
print(programmingLanguages[0])

var names:[String] = ["Oliver", "Elijah", "James"]
print("Before appending \(names)")
names.append("Masthan")
print("After appending \(names)")

print("Before inserting \(names)")
names.insert("Benjamin", at: 2)
print("After inserting \(names)")
print(names.count)
names.sort()

print("After sorting \(names)")

names.reverse()
print("After reversing \(names)")

names.remove(at: 2)
print("After removing \(names)")

names.swapAt(1, 2)
print("After swapping \(names)")

var oddNumbers = [1,3,5,7]
var evenNumbers = [2,4,6,8]
oddNumbers.append(contentsOf: evenNumbers)
print("After combining \(oddNumbers)")


