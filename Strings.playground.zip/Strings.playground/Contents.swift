import UIKit

//sheet1
var fact = "Swift is a type safe language"
var dev = "Development of Swift began in 2010"
var author = "Swift was created by Chris Lattner"
print(fact.count)
fact += ", it has a better memory management"
print(fact)
dev.append(" by Apple")
print(dev)
print(author.lowercased())
print(author.uppercased())
print(author[author.startIndex])
print(author[author.index(before: author.endIndex)])
print(dev[dev.startIndex])
print(dev[dev.index(before: dev.endIndex)])
print(author[author.index(after: author.startIndex)])
print(author[author.index(author.startIndex,offsetBy: 5)])
print(author[author.index(author.endIndex,offsetBy: -5)])
print(fact[fact.index(fact.endIndex,offsetBy: -4)])


//sheet2
var shoppingList = "The shopping list contains: "
var foodItems = "Cheese, Butter, Chocolate Spread"
var clothes = "Socks, T-shirts"

if clothes.hasPrefix("Socks") {
print("The first item in clothes is socks")
}else{
print("socks is not the first item in clothes")
}

print(foodItems.split(separator: ","))

if clothes.contains(",") {
print("Clothes contains more than one item")
}else{
print("Clothes contain only one item")
}

print(foodItems[foodItems.startIndex..<foodItems.index(foodItems.endIndex,offsetBy: -7)])

shoppingList += foodItems[foodItems.index(foodItems.startIndex, offsetBy:8)..<foodItems.endIndex]
print(shoppingList)

clothes.remove(at: clothes.firstIndex(of: "T")!)
print(clothes)

clothes.remove(at: clothes.firstIndex(of: "-")!)
print(clothes)

print("\(shoppingList), \(clothes)")

clothes.insert(contentsOf: ", Trousers", at:
clothes.endIndex)
print(clothes)

var firstIndexOfR = shoppingList.index(after:shoppingList.firstIndex(of: "r")!)
print(shoppingList[..<firstIndexOfR])

//sheet3
var course = "44643-Mobile Computing-iOS"

print(course[course.startIndex..<course.index(course.startIndex, offsetBy:5)])
print(course[course.endIndex..<course.index(course.endIndex,offsetBy:-20)])



