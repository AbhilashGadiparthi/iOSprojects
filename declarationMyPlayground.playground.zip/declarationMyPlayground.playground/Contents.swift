import UIKit

//declaration of variable

var mobileBrand="Apple"
mobileBrand="samsung"
print(mobileBrand)

let pi=3.14
//pi=3 pi is a let you can change the value for pi as you defined it as let
print(pi)

//explicit declaration of variables

var age : Int = 23
age = age*2
print(age)


var AweMessage="This is superb!"
print(AweMessage)
print("awemessage")

var course1 = "iOS"

