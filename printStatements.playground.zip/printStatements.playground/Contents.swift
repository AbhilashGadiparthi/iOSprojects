import UIKit

//for printing a paragraph
print("""
Hello
World!
""")

//printing the output by braking
print("Hello All, \rwelcome to swift programming")


//Let
let WelcomeMessage : String = "Hello!"
print("WelcomeMessage")

//string enterpolation
var age=23
print("you are \(age) years old and in another \(age) years, you will be \(age*2)")

var programingLanguage = "swift"
print("My programing language is \(programingLanguage)")

print("Hello All,10,10.25")


//terminator

print("Welcome to shift programming")
print("Fall 2021")
print("********")
print("Welcome to shift programming", terminator : "-")
print("Fall 2021")

//separator

print("The list of numbers are")
print(1,2,3,4,5,6)
print("The new pattern of numbers are")
print("1,2,3,4,5,6", separator : "-")


