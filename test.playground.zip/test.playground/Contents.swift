import UIKit


var pi=Double(3.14)
var r=Double(7.5)
var circumference=Double(2*pi*r)
print(circumference)
