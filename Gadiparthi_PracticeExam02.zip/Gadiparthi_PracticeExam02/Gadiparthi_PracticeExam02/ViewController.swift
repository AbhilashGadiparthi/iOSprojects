//
//  ViewController.swift
//  Gadiparthi_PracticeExam02
//
//  Created by Abhilash Gadiparthi on 4/9/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var TypeOL: UITextField!
    
    
    @IBOutlet weak var AmountOL: UITextField!
    

    @IBOutlet weak var InterestOL: UITextField!
    
    
    @IBOutlet weak var TermOL: UITextField!
    
    var LoanType=""
    var LoanAmount=""
    var InterestRate=""
    var Term=""
    var MonthlyEMI=0.00
    var image=""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CalBtn(_ sender: Any) {
        LoanType=TypeOL.text!
        LoanAmount=AmountOL.text!
        InterestRate=InterestOL.text!
        Term=TermOL.text!
        var totalmonths=(Int(Term)! * 12)
        var monthlyintrate=((Double(InterestRate)!/12))/100
        MonthlyEMI = Double(LoanAmount)! * (monthlyintrate * pow(1+monthlyintrate,Double(totalmonths)))/(pow(1+monthlyintrate,Double(totalmonths))-1)
        
        if LoanType=="Car"{
            image="Car"
            
        }
        else if LoanType=="Personal"{
            image="Personal"
        }
        else{
            image="Home"
        }
        
    }
    
    
    @IBAction func ResetBtn(_ sender: Any) {
        LoanAmount=""
        LoanType=""
        InterestRate=""
        Term=""
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let transaction = segue.identifier
        if(segue.identifier=="CalSegue"){
            let destination = segue.destination as! ResultViewController
            //Assign
            
            destination.LoanType=LoanType
            destination.LoanAmount=LoanAmount
            destination.InterestRate=InterestRate
            destination.Term=Term
            destination.MonthlyEMI=MonthlyEMI
            destination.image=image
            
        }
            }
    
}

