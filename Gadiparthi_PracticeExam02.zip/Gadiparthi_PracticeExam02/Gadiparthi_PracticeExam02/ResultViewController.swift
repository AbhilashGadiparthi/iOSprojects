//
//  ResultViewController.swift
//  Gadiparthi_PracticeExam02
//
//  Created by Abhilash Gadiparthi on 4/9/24.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var TypeOL: UILabel!
    
    
    @IBOutlet weak var AmountOL: UILabel!
    
    
    @IBOutlet weak var IntrestRateOL: UILabel!
    
    
    @IBOutlet weak var MonthlyEMIOL: UILabel!
    
    
    @IBOutlet weak var ImageOL: UIImageView!
    
    var LoanType=""
    var LoanAmount=""
    var InterestRate=""
    var Term=""
    var MonthlyEMI=0.00
    var image=""
    var formattedEMI = String(format: "%.2f", MonthlyEMI)


    override func viewDidLoad() {
        super.viewDidLoad()
  
        TypeOL.text="Loan Type: \(LoanType)"
        AmountOL.text="Enterd Loan Amount: \(LoanAmount)"
        IntrestRateOL.text="Enterd Interest Rate: \(InterestRate)"
        MonthlyEMIOL.text="Calculated Monthly EMI: \(MonthlyEMI)"
        ImageOL.image=UIImage(named: image)
    
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
