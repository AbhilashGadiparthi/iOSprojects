//
//  ViewController.swift
//  Gadiparthi_SearchApp
//
//  Created by Abhilash Gadiparthi on 3/19/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!

    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var prevOL: UIButton!
    
    @IBOutlet weak var resetOL: UIButton!
    
    @IBOutlet weak var nextOL: UIButton!
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    @IBOutlet weak var searchOL: UIButton!
    
    var imageNum = 0;
    var topic: Int = -1
    var count : Int = -1
    
    
    var arr = [["Jr NTR","Mahesh Babu","SR NTR","Bala Krishna","Kalyan Ram"],["Lily","Roses","Tulip","Sunflower","Lavender"],["Tiger","Lion","Elephant","Dog","Cat"]]
    var actors_keywords = ["Jr NTR","Mahesh Babu","SR NTR","Bala Krishna","Kalyan Ram","Actors","actors","actor","Actor","hero","film","movie","MOVIE","ACTOR","FILM","HERO","ACTORS"]
    
    var flowers_keywords = ["Lily","Roses","Tulip","Sunflower","Lavender","garden","blossom","botany","flower","flowers","GARDEN","FLOWERS","FLOWER"]
    
    var animals_keywords = ["Tiger","Lion","Elephant","Dog","Cat","animals","Animals","animal","zoo","wildlife","Animal","ANIMAL","ANIMALS"]
    
    var topics_array = [[
        "Jr NTR, born Nandamuri Taraka Rama Rao Jr on May 20, 1983, in Hyderabad, India, is a significant figure in Indian cinema. Hailing from the esteemed Nandamuri family, he has left an indelible mark on Telugu cinema, transitioning from a child artist in Brahmarshi Vishwamitra to a leading star in Student No.1 directed by S.S. Rajamouli. His versatility shines in acclaimed performances in films like Simhadri, Yamadonga, and Aravinda Sametha Veera Raghava. Jr NTR's talents extend beyond acting to hosting TV shows and playback singing, garnering a global fanbase and cementing his status as a beacon of talent in Telugu cinema.",
        "Mahesh Babu, born on August 9, 1975, in Chennai, India, is a prominent figure in Telugu cinema, hailing from a family deeply entrenched in the industry. With a debut as a child artist in Needa (1979) and later as a lead in Raja Kumarudu (1999), he has amassed immense popularity for his charismatic performances in films like Okkadu, Pokiri, and Bharat Ane Nenu. Renowned for his suave demeanor and acting prowess, Mahesh Babu enjoys a dedicated fanbase. Apart from his cinematic endeavors, he actively engages in philanthropy, further solidifying his status as a leading personality in Indian cinema.",
        "Sr. NTR, born Nandamuri Taraka Rama Rao on May 28, 1923, in Nimmakuru, India, was a legendary figure in Telugu cinema and politics. Rising to prominence with iconic roles in films like Pathala Bhairavi and Maya Bazaar, he became one of the most revered actors in Indian cinema history. Beyond his cinematic achievements, Sr. NTR ventured into politics, founding the Telugu Desam Party (TDP) and serving as Chief Minister of Andhra Pradesh for three terms. His legacy is deeply ingrained in Telugu culture, remembered for his charismatic screen presence and unwavering commitment to public service.",
        " Balakrishna, born Nandamuri Balakrishna on June 10, 1960, in Chennai, India, is a prominent figure in Telugu cinema. As part of the renowned Nandamuri family, he has carved a niche for himself with powerful performances in films like Simha, Legend, and Gautamiputra Satakarni. Balakrishna's contributions to cinema extend beyond acting, as he also serves as a member of the Andhra Pradesh Legislative Assembly. With a dedicated fan following, he continues to uphold the family legacy while making his mark as a versatile actor and public figure.",
        "Kalyan Ram, born Nandamuri Kalyan Ram on July 5, 1978, in Hyderabad, India, is a notable figure in Telugu cinema. Coming from the illustrious Nandamuri family, he has made his mark as an actor and producer. Known for his roles in films like Athanokkade and Pataas, Kalyan Ram has showcased his versatility and talent on the silver screen. Additionally, he has produced several successful films under his banner, N.T.R. Arts. With a dedicated fan following, Kalyan Ram continues to contribute to the vibrant landscape of Telugu cinema."],
        ["Lilies are tall perennials ranging in height from 2–6 ft. They form naked or tunicless scaly underground bulbs which are their organs of perennation. In some North American species the base of the bulb develops into rhizomes, on which numerous small bulbs are found. Some species develop stolons. Most bulbs are buried deep in the ground, but a few species form bulbs near the soil surface.",
         "A Rose is either a woody perennial flowering plant of the genus Rosa in the family Rosaceae, or the flower it bears. There are over three hundred species and tens of thousands of cultivars.They form a group of plants that can be erect shrubs, climbing, with stems that are often armed with sharp prickles. Their flowers vary in size and shape and are usually large and showy, in colours ranging from white through yellows and reds.",
         "The tulip flower, known for its vibrant colors and elegant shape, is a symbol of springtime and renewal. Originating from Central Asia, tulips have become widely cultivated and cherished worldwide for their beauty. With a variety of hues ranging from red and yellow to purple and white, tulips add a splash of color to gardens, parks, and floral arrangements. These graceful blooms are celebrated for their simplicity and grace, making them a beloved choice for both ornamental and decorative purposes.",
         "The common sunflower (Helianthus annuus) is a species of large annual forb of the genus Helianthus. It is commonly grown as a crop for its edible oily seeds. Apart from cooking oil production, it is also used as livestock forage (as a meal or a silage plant), as bird food, in some industrial applications, and as an ornamental in domestic gardens. Wild H. annuus is a widely branched annual plant with many flower heads. ",
        "Lavender is a fragrant herb known for its beautiful purple flowers and aromatic leaves. With a soothing scent, it is widely used in aromatherapy, perfumes, and culinary preparations. Lavender's calming properties make it a popular choice for relaxation and stress relief. Additionally, it has been traditionally used for its medicinal benefits, including promoting sleep and soothing skin irritations. This versatile plant is cherished for its delightful aroma and therapeutic qualities, making it a beloved herb worldwide."],
        ["The tiger, a majestic and powerful carnivore, is one of the most iconic animals on Earth. Known for its striking orange coat adorned with dark stripes, tigers inhabit various habitats across Asia, from dense forests to grasslands. As apex predators, they play a crucial role in maintaining ecological balance. However, tigers face numerous threats, including habitat loss, poaching, and human-wildlife conflict, leading to a decline in their populations. Conservation efforts are underway to protect these magnificent creatures and ensure their survival for future generations to admire and cherish.",
         "The lion, often referred to as the king of the jungle, is a majestic and powerful carnivorous mammal native to various regions of Africa and Asia. Known for its distinctive mane, muscular build, and ferocious roar, the lion symbolizes strength, courage, and pride in many cultures around the world. Living in social groups called prides, lions are apex predators, preying mainly on large herbivores. Despite their regal appearance, lions face threats such as habitat loss, poaching, and human-wildlife conflict, highlighting the importance of conservation efforts to ensure their survival in the wild. ",
         "The elephant, Earth's largest land animal, embodies majesty and strength. With its distinctive trunk, ivory tusks, and wrinkled skin, it commands attention and admiration. These gentle giants are highly intelligent and possess remarkable social bonds within their herds. Sadly, they face threats from habitat loss, poaching for ivory, and human-wildlife conflict, highlighting the urgent need for conservation efforts to ensure their survival for generations to come.",
         "Dogs, often hailed as man's best friend, embody loyalty, companionship, and boundless affection. Their wagging tails and eager eyes epitomize joy and unwavering devotion. Whether bounding through fields with playful exuberance or curling up at our feet in quiet contentment, dogs enrich our lives in countless ways, leaving indelible paw prints on our hearts.",
         "The cat, a small carnivorous mammal, is known for its agility, grace, and independent nature. Domesticated cats, descendants of wild ancestors, have been cherished companions to humans for centuries. Renowned for their hunting prowess and affectionate behavior, cats come in various breeds, each with unique characteristics. With their soft fur, whiskers, and captivating eyes, cats have earned a special place in many households worldwide, bringing joy and companionship to their owners."]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resultImage.image = UIImage(named: "welcome")
        searchOL.isEnabled = false
        prevOL.isHidden = true
        nextOL.isHidden = true
        resetOL.isHidden = true
    }

    @IBAction func searchTextField(_ sender: UITextField) {
        if(searchTextField.text!.isEmpty)
        {
            searchOL.isEnabled = false
        }
        else
        {
            searchOL.isEnabled = true
        }
    }
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        searchOL.isEnabled = true
        let a = searchTextField.text!
        count = 0
        if(actors_keywords.contains(a)){
            prevOL.isHidden = false
            nextOL.isHidden = false
            resetOL.isHidden = false
            topicInfoText.isHidden = false;
            topic = 0
            resultImage.image = UIImage(named: arr[topic][count])
            topicInfoText.text = topics_array[topic][count]
            if(count==0){
                prevOL.isEnabled = false
                
            }
            else{
                prevOL.isEnabled = true
                
            }
            if(count == arr[topic].count-1){
                nextOL.isEnabled = false
                
            }
            else{
                nextOL.isEnabled = true
                
            }
            resetOL.isEnabled = true
        }
        else if(flowers_keywords.contains(a)){
            prevOL.isHidden = false
            nextOL.isHidden = false
            resetOL.isHidden = false
            topicInfoText.isHidden = false;
            topic = 1
            resultImage.image = UIImage(named: arr[topic][count])
            topicInfoText.text = topics_array[topic][count]
            if(count==0){
                prevOL.isEnabled = false
                
            }
            else{
                prevOL.isEnabled = true
                
            }
            if(count == arr[topic].count-1){
                nextOL.isEnabled = false
                
            }
            else{
                nextOL.isEnabled = true
                
            }
            resetOL.isEnabled = true
        }
       else if(animals_keywords.contains(a)){
           prevOL.isHidden = false
           nextOL.isHidden = false
           resetOL.isHidden = false
           topicInfoText.isHidden = false;
            topic = 2
           resultImage.image = UIImage(named: arr[topic][count])
           topicInfoText.text = topics_array[topic][count]
           if(count==0){
               prevOL.isEnabled = false
               
           }
           else{
               prevOL.isEnabled = true
               
           }
           if(count == arr[topic].count-1){
               nextOL.isEnabled = false
               
           }
           else{
               nextOL.isEnabled = true
               
           }
           resetOL.isEnabled = true
        }
        else if(!actors_keywords.contains(a) && !animals_keywords.contains(a) && !flowers_keywords.contains(a)){
            topic = -1
            resultImage.image = UIImage(named: "oops")
            prevOL.isHidden = true
            nextOL.isHidden = true
            resetOL.isHidden = true
            topicInfoText.isHidden = true;
            
        }
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        count-=1
        resultImage.image = UIImage(named: arr[topic][count])
        topicInfoText.text = topics_array[topic][count]
        if(count==0){
            prevOL.isEnabled = false
        }
        else{
            prevOL.isEnabled = true
        }
        if(count == arr[topic].count-1){
            nextOL.isEnabled = false
        }
        else{
            nextOL.isEnabled = true
        }
        resetOL.isEnabled = true
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        searchTextField.text = ""
        searchOL.isEnabled = false
        
        prevOL.isHidden = true
        nextOL.isHidden = true
        resetOL.isHidden = true
        topicInfoText.text = ""
        resultImage.image = UIImage(named: "welcome")
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        count+=1
        resultImage.image = UIImage(named: arr[topic][count])
        topicInfoText.text = topics_array[topic][count]
        if(count==0){
            prevOL.isEnabled = false
        }
        else{
            prevOL.isEnabled = true
        }
        if(count == arr[topic].count-1){
            nextOL.isEnabled = false
        }
        else{
            nextOL.isEnabled = true
        }
        resetOL.isEnabled = true
    }
    
    
}




