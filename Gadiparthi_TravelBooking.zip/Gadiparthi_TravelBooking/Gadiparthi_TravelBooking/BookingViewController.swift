//
//  ViewController.swift
//  Gadiparthi_TravelBooking
//
//  Created by Abhilash Gadiparthi on 3/29/24.
//

import UIKit

class BookingViewController: UIViewController {
    
    var TravellerName=""
    var NoOfTravellers=""
    var CabinType=""
    var result=""
    var image=""
    var total=0.0
    
    
    @IBOutlet weak var travelNameOL: UITextField!
    
    
    @IBOutlet weak var noOfTravelsOL: UITextField!
    
    
    @IBOutlet weak var cabinTypeOL: UITextField!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func bookNowBtn(_ sender: Any) {
        
        TravellerName=travelNameOL.text!
        NoOfTravellers=noOfTravelsOL.text!
        CabinType=cabinTypeOL.text!
        
        if CabinType == "Economy"
        {
            image="economy"
            total = 125*Double(NoOfTravellers)!
            
        }
        else if CabinType=="Luxury"
        {
            image="luxury"
            total = 200*Double(NoOfTravellers)!
        }
        else
        {
            image="notfound"
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let transaction = segue.identifier
            if(segue.identifier=="resultSegue"){
                let destination = segue.destination as! ResultViewController
                //Assign
                destination.image=image
                destination.result=result
                destination.TravellerName=TravellerName
                destination.NoOfTravellers=NoOfTravellers
                destination.CabinType=CabinType
                destination.total=total
            }
            
        
    }
    
}

