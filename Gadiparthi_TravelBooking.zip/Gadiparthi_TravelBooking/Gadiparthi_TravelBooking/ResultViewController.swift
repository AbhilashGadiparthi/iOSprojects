//
//  ResultViewController.swift
//  Gadiparthi_TravelBooking
//
//  Created by Abhilash Gadiparthi on 3/29/24.
//

import UIKit

class ResultViewController: UIViewController {
    var TravellerName=""
    var NoOfTravellers=""
    var CabinType=""
    var result=""
    var image=""
    var total=0.0
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    @IBOutlet weak var resultOL: UILabel!
    
    @IBOutlet weak var travellerNameOL: UILabel!
    
    
    @IBOutlet weak var noOfTravellersOL: UILabel!
    
    
    @IBOutlet weak var CabinTypeOL: UILabel!
    
    
    @IBOutlet weak var totalCostOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if image=="notfound"{
            imageOL.image = UIImage(named: image)
            resultOL.text="There is no selected class. Please choose a valid class."
        }
        else{
            imageOL.image=UIImage(named: image)
            resultOL.text="Hello \(TravellerName), your Booking is Confirmed"
            travellerNameOL.text="Name: \(TravellerName)"
            noOfTravellersOL.text="No Of Travellers: \(NoOfTravellers)"
            CabinTypeOL.text="Cabin Class: \(CabinType)"
            totalCostOL.text="Total: \(total)$"
        }
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
