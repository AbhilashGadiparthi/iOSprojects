//
//  Movies.swift
//  Gadiparthi_moviesApp
//
//  Created by Abhilash Gadiparthi on 4/10/24.
//

import Foundation

// Movies struct
struct Movies {
    var genre = ""
    var MovieList: [MovieList] = []
}

// MovieList struct
struct MovieList {
    var movieName = ""
    var movieImage = ""
    var movieInfo = ""
}

// Creating movies for each genre
var dramaMovies =
    Movies(genre: "Drama", MovieList: [
        MovieList(movieName: "The Shawshank Redemption", movieImage: "shawshankredemption", movieInfo: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency."),
        MovieList(movieName: "Forrest Gump", movieImage: "forrestgump", movieInfo: "The presidencies of Kennedy and Johnson, the Vietnam War, the Watergate scandal and other historical events unfold from the perspective of an Alabama man with an IQ of 75, whose only desire is to be reunited with his childhood sweetheart."),
        MovieList(movieName: "The Godfather", movieImage: "godfather", movieInfo: "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son."),
        MovieList(movieName: "Schindler's List", movieImage: "schindlerslist", movieInfo: "In German-occupied Poland during World War II, Oskar Schindler gradually becomes concerned for his Jewish workforce after witnessing their persecution by the Nazi Germans."),
        MovieList(movieName: "The Green Mile", movieImage: "greenmile", movieInfo: "The lives of guards on Death Row are affected by one of their charges: a black man accused of child murder and rape, yet who has a mysterious gift.")
    ])

var actionMovies = Movies(genre: "Action", MovieList: [
    MovieList(movieName: "The Dark Knight", movieImage: "darkknight", movieInfo: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice."),
    MovieList(movieName: "Inception", movieImage: "inception", movieInfo: "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O."),
    MovieList(movieName: "Die Hard", movieImage: "diehard", movieInfo: "An NYPD officer tries to save his wife and several others taken hostage by German terrorists during a Christmas party at the Nakatomi Plaza in Los Angeles."),
    MovieList(movieName: "The Matrix", movieImage: "matrix", movieInfo: "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers."),
    MovieList(movieName: "Gladiator", movieImage: "gladiator", movieInfo: "A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family and sent him into slavery.")])

var horrorMovies = Movies(genre: "Horror", MovieList: [
    MovieList(movieName: "The Shining", movieImage: "shining", movieInfo: "A family heads to an isolated hotel for the winter where a sinister presence influences the father into violence, while his psychic son sees horrific forebodings from both past and future."),
    MovieList(movieName: "The Exorcist", movieImage: "exorcist", movieInfo: "When a teenage girl is possessed by a mysterious entity, her mother seeks the help of two priests to save her daughter."),
    MovieList(movieName: "Psycho", movieImage: "psycho", movieInfo: "A Phoenix secretary embezzles $40,000 from her employer's client, goes on the run, and checks into a remote motel run by a young man under the domination of his mother."),
    MovieList(movieName: "Alien", movieImage: "alien", movieInfo: "After a space merchant vessel receives an unknown transmission as a distress call, one of the crew is attacked by a mysterious life form and they soon realize that its life cycle has merely begun."),
    MovieList(movieName: "The Conjuring", movieImage: "conjuring", movieInfo: "Paranormal investigators Ed and Lorraine Warren work to help a family terrorized by a dark presence in their farmhouse.")
])


var comedyMovies = Movies(genre: "Comedy", MovieList: [
    MovieList(movieName: "The Hangover", movieImage: "hangover", movieInfo: "Three buddies wake up from a bachelor party in Las Vegas, with no memory of the previous night and the bachelor missing."),
    MovieList(movieName: "Superbad", movieImage: "superbad", movieInfo: "Two co-dependent high school seniors are forced to deal with separation anxiety after their plan to stage a booze-soaked party goes awry."),
    MovieList(movieName: "The Big Lebowski", movieImage: "biglebowski", movieInfo: "Jeff 'The Dude' Leboswki, mistaken for a millionaire of the same name, seeks restitution for his ruined rug and enlists his bowling buddies to help get it."),
    MovieList(movieName: "Anchorman: The Legend of Ron Burgundy", movieImage: "anchorman", movieInfo: "Ron Burgundy is San Diego's top-rated newsman in the male-dominated broadcasting of the 1970s, but that's all about to change for Ron and his cronies when an ambitious woman is hired as a new anchor."),
    MovieList(movieName: "Monty Python and the Holy Grail",movieImage: "holygrail",movieInfo: "King Arthur and his Knights of the Round Table embark on a surreal, low-budget search for the Holy Grail, encountering many, very silly obstacles.")
])

var sciFiMovies = Movies(genre: "Science Fiction", MovieList: [
    MovieList(movieName: "Interstellar", movieImage: "interstellar", movieInfo: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival."),
    MovieList(movieName: "The Fifth Element", movieImage: "fifthelement", movieInfo: "In a futuristic world, a cab driver unwittingly becomes the central figure in the search for a legendary cosmic weapon that can save Earth from destruction."),
    MovieList(movieName: "Blade Runner", movieImage: "bladerunner", movieInfo: "In a dystopian future Los Angeles, a cop hunts down rogue artificial humans known as replicants, leading to existential questions about identity and humanity."),
    MovieList(movieName: "Star Wars: A New Hope", movieImage: "starwars.jpg", movieInfo: "A young farm boy named Luke Skywalker embarks on a journey to rescue Princess Leia and defeat the evil Sith Lord Darth Vader, discovering his destiny as a Jedi Knight in the process."),
    MovieList(movieName: "Eternal Sunshine of the Spotless Mind", movieImage: "eternalsunshine", movieInfo: "After a painful breakup, a man undergoes a procedure to erase all memories of his ex-girlfriend, but soon realizes he wants to hold onto them, leading to a surreal journey through his own mind.")
])

// Creating movies struct instances for each genre
let genres = [dramaMovies, actionMovies, horrorMovies, comedyMovies, sciFiMovies]
