//
//  MovieListViewController.swift
//  Gadiparthi_moviesApp
//
//  Created by Abhilash Gadiparthi on 4/10/24.
//

import UIKit

class MovieListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.MovieList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var cell = movieListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        
        //populate the cell
        cell.textLabel?.text = movies.MovieList[indexPath.row].movieName
        
        //return the cell
        return cell
    }
    
    var movies = Movies()
    
    @IBOutlet weak var movieListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        movieListTableView.dataSource = self
        movieListTableView.delegate = self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition  = segue.identifier
        if(transition == "movieInfoSegue")
        {
            var destination = segue.destination as! MovieInfoViewController
            destination.movieInfo = movies.MovieList[(movieListTableView.indexPathForSelectedRow?.row)!]
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
