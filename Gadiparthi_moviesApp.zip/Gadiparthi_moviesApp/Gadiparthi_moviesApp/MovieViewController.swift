//
//  ViewController.swift
//  Gadiparthi_moviesApp
//
//  Created by Abhilash Gadiparthi on 4/10/24.
//

import UIKit

class MovieViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let genre = genres
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return genre.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var cell = movieTableView.dequeueReusableCell(withIdentifier: "genreCell", for: indexPath)
        
        //populate the cell
        cell.textLabel?.text = genre[indexPath.row].genre
        
        //return the cell
        return cell
    }
    
    @IBOutlet weak var movieTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        movieTableView.dataSource = self
        movieTableView.delegate = self
        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "listsSegue")
        {
            var destination = segue.destination as! MovieListViewController
            destination.movies = genre[(movieTableView.indexPathForSelectedRow?.row)!]
        }
    }

}

