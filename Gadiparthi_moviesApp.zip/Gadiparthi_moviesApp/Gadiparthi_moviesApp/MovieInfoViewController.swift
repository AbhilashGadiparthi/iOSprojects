//
//  MovieInfoViewController.swift
//  Gadiparthi_moviesApp
//
//  Created by Abhilash Gadiparthi on 4/10/24.
//

import UIKit

class MovieInfoViewController: UIViewController {
    
    
    @IBOutlet weak var movieImagViewOL: UIImageView!
    
    @IBOutlet weak var movieInfoOL: UITextView!
    
    var movieInfo = MovieList()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "\(movieInfo.movieName)"
        
        movieImagViewOL.image = UIImage(named: movieInfo.movieImage)
        movieInfoOL.isHidden = true
        // Do any additional setup after loading the view.
    }
    
    @IBAction func showInfoAction(_ sender: UIButton) {
        movieInfoOL.isHidden = false
        movieInfoOL.text = movieInfo.movieInfo
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
