//
//  ViewController.swift
//  Gadiparthi_PracticeExam03
//
//  Created by Abhilash Gadiparthi on 4/16/24.
//

import UIKit

class Contact{
    var ContactName:String?
    var ContactNumber:String?
    var contact:String?
    
    init(ContactName: String? = nil, ContactNumber: String? = nil) {
        self.ContactName = ContactName
        self.ContactNumber = ContactNumber
    }
}



class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        var cell=TableViewOL.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        //populate a cell
        cell.textLabel?.text=contacts[indexPath.row].ContactName
        //return a cell
        return cell
    }
    
    
    var contacts=[Contact]()
    
    @IBOutlet weak var TableViewOL: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        TableViewOL.delegate=self
        TableViewOL.dataSource=self
        
        let p1=Contact(ContactName:"Abhilash" ,ContactNumber:"1234567890" )
        contacts.append(p1)
        
        let p2=Contact(ContactName:"Narendra" ,ContactNumber:"9876543210" )
        contacts.append(p2)
        
        let p3=Contact(ContactName:"Kamleesha" ,ContactNumber:"5678901234")
        contacts.append(p3)
        
        let p4=Contact(ContactName:"Santosh" ,ContactNumber:"7654321890" )
        contacts.append(p4)
        
        let p5=Contact(ContactName:"Chinna robo" ,ContactNumber:"9876541230" )
        contacts.append(p5)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if(segue.identifier == "ContactSegue"){
            
            let destination = segue.destination as! ProfileViewController
            destination.contact = contacts[(TableViewOL.indexPathForSelectedRow?.row)!]
        }
    }

}

