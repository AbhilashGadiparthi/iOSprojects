//
//  GadiparthiAnimalController.swift
//  Gadiparthi_Exam3
//
//  Created by Abhilash Gadiparthi on 4/18/24.
//

import UIKit

class GadiparthiAnimalController: UIViewController {
    
    var animal:[Animal] = []
    
    var titleName = ""
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    @IBOutlet weak var nameOL: UILabel!
    
    
    @IBOutlet weak var descriptionOL: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        nameOL.text = "\(animal[0].name!)"
        descriptionOL.text="\(animal[0].information!)"
        
        
        self.title = titleName
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
