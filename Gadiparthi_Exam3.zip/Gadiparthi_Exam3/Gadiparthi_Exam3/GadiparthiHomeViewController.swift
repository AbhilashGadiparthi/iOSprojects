//
//  ViewController.swift
//  Gadiparthi_Exam3
//
//  Created by Abhilash Gadiparthi on 4/18/24.
//

import UIKit

class GadiparthiHomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return animals.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = GadiparthiTVOL.dequeueReusableCell(withIdentifier: "GadiparthiCell", for: indexPath)
            cell.textLabel?.text = animals[indexPath.row]
            return cell
        }
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            performSegue(withIdentifier: "GadiparthiDescriptionSegue", sender: indexPath.row)
        }
    
    @IBOutlet weak var GadiparthiTVOL: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        GadiparthiTVOL.dataSource=self
        GadiparthiTVOL.delegate=self
        self.title = "Animals"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "GadiparthiDescriptionSegue",
           let selectedIndex = sender as? Int,
           let destination = segue.destination as? GadiparthiAnimalController {
            // Access the Animal object directly at the specified index
            destination.animal = allAnimal
            // Assuming `titleName` is a property in GadiparthiAnimalController
            destination.titleName = animals[selectedIndex]
        }
    }

}

