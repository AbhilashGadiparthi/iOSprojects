import UIKit

var httpError = (errorCode : 404 , errorMessage : "page not found")
print(httpe=Error)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage)

var name=("john","smith")
var fName = name.0
var lName=name.1
print(fname , terminator : "," )
print(lname)

var name("john","smith")
var fName=name.0
var lName=name.1
(fName,lName)=(lName,fName)
print(fName,lName)

var origin = (x:0 , y:0)
var point=origin
print(point)

let city=(name : "Maryville" , population: 11,000)
let(cityName,cityPopulation)=(city.0,city.1)
print(city.0)
print(city.1)

let groceries=("onion","bread")
print(groceries.0)
print(groceries.1)
print(type(of:groceries))

var cricketkit = ("KeepingGlov" , "Helmet" ,("bat","ball") )
print(cricketkit.0)
print(crickekit.1)
print(cricketkit.(2.0))
print(cricketkit.(2.1))

